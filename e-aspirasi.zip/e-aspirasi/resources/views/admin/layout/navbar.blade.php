<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="#">
        <i class="bi bi-lightning-fill"></i> E-Aspirasi
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
              aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav ms-auto align-items-lg-center gap-3 mt-3 mt-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="/navbar">
              <i class="bi bi-house-door-fill"></i> Home
            </a>
          </li>
          <li class="nav-item dropdown-alert-wrapper">
            <a class="nav-link" onclick="toggleAspirasiAlert(event)">
              <i class="bi bi-chat-left-text-fill"></i> Aspirasi
            </a>
            <!-- Alert Dropdown -->
            <div id="aspirasi-alert" class="alert alert-info shadow">
              <strong><i class="bi bi-info-circle-fill"></i> Unit:</strong>
              <ul class="mb-0 mt-2 ps-3">
              <li><a href="/aspirasi/ppks" class="alert-link">PPKS</a></li>
              <li><a href="/aspirasi/akademik" class="alert-link">Akademik</a></li>
                <li><a href="/aspirasi/sarpras" class="alert-link">Sarana dan Prasarana</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="btn btn-logout" href="/logout">
              <i class="bi bi-box-arrow-right"></i> Logout
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>