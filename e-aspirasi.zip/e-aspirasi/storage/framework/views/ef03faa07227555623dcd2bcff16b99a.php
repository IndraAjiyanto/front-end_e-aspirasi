<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Laporan Sarana & Prasarana</title>

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />

  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f0f2f5;
    }

    .card {
      border-radius: 10px;
    }

    .text-primary {
      color: #198754 !important; /* Warna hijau khas sarpras */
    }

    .btn-outline-primary {
      border-color: #198754;
      color: #198754;
    }

    .btn-outline-primary:hover {
      background-color: #198754;
      color: white;
    }

    .status-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
    }

    .status-container i {
      margin-left: auto; /* Memastikan ikon status berada di sebelah kanan */
    }

    .status-answered {
      color: green;
      font-size: 1.5rem;
    }

    .status-in-progress {
      color: #ffc107;
      font-size: 1.5rem;
    }
  </style>
</head>
<body>

  <div class="container py-5">
    <div class="row mb-4">
      <div class="col text-center">
        <h2 class="fw-bold text-primary">
          <i class="bi bi-tools me-2"></i> Laporan Sarana & Prasarana
        </h2>
        <p class="text-muted">Berikut adalah laporan terkait fasilitas kampus yang memerlukan perhatian.</p>
      </div>
    </div>

    <div class="mb-4 d-flex gap-2">
    <a href="/dashboard" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Kembali ke Menu Awal
          </a>
          </div>
          
    <?php $__empty_1 = true; $__currentLoopData = $sarpras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="card mb-3 shadow-sm border-0">
        <div class="card-body">
          <p class="card-text text-secondary"><?php echo e(\Illuminate\Support\Str::limit($item->isi, 100)); ?></p>
          <div class="status-container">
            <a href="/aspirasi/lihatppks" class="btn btn-outline-primary">
              <i class="bi bi-eye-fill me-1"></i> Lihat
            </a>

            <!-- Tanda ceklis jika aspirasi sudah terbalas -->
            <?php if($item->status == 'terbalas'): ?>
              <i class="bi bi-check-circle status-answered" title="Sudah Terbalas"></i>
            <!-- Tanda jika aspirasi sedang diproses -->
            <?php elseif($item->status == 'diproses'): ?>
              <i class="bi bi-hourglass-split text-warning status-in-progress" title="Sedang Diproses"></i>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="alert alert-info">
        <i class="bi bi-info-circle"></i> Belum ada laporan yang masuk untuk sarana & prasarana.
      </div>
    <?php endif; ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\e-aspirasi\resources\views/admin/sarana_prasarana.blade.php ENDPATH**/ ?>